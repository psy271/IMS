using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;

namespace IMS
{
	class GVariant
	{
   
        public static string gLogin_id = null;

        public static string LOGIN_ID { get { return gLogin_id; } set { gLogin_id = value; } }
      
	}
}
